# P11 실행 결과 — 2026-10-23

지시문 docs/instructions/INSTRUCTIONS_P11.md의0절 한정. pixel-forge codex/g2-approved-handoff→main ff(ad51afb) 후설치·build·301pass/2skip·규칙검사와push완료. 후속CLI/검기6쌍코드도main에서검증한다. seonggeom은codex/g2-approved-handoff만, 기존PR/main미병합.

- archive/restore는기본꺼짐. 입력PNG/메타·참조/state/사용spec·hash를별도art-source구조로복사·모든hash검증후복원. 합성archive→삭제→restore→make의PNG/manifest바이트동일. 원본미수신이므로local orphan art-source예약만했고 원격push하지않음. GitHubAPI GET/GraphQL Forbidden으로비공개확인불가, 브랜치별비공개설정도불가. JPEG4장은derived:true인수령목록만.
- Godot공식4.7.2.stable.official.ed1daf0bf+export templates SHA512검증. 큰templates는240s시간제한후이어받아완료. 지정회귀153/0+실제FX매핑16/0, GPU오버레이시2캡처포함18/0. g2_timing대응기존파일은g2_render_contract. 4.6.3대비표는P11_ENGINE_VERSION.md.
- 읽기전용16_gameplay_v04모든primary20레벨→고유6쌍과04_skills.angle전체출처표. reach/3환산·pxlJSON주입·8방향3프레임의호90~100%/각도±5°/안쪽투명/팔레트QA0. FX_ATTACK_SPEC_TABLE.md. 기존검기3종·기존후보PNG18개보존, 신규candidate검기6쌍만추가.
- 실제primary의reach/angle동적매핑,레벨업다음공격반영. 사양외강화/방향오차5°초과는도형유지. 이벤트키에aim/reach/angle을포함해동시서로다른공격이잘못대체되는경우방지. wave는기존beam크기불일치만기록·미연결.
- 기존캐릭터는재변환안함. 세라idle0/attack0/attack4/death0머리proxy14/26/19/16·키48/40/48/48·어깨proxy17/26/21/23. 발기준2배시트+측정구간표만,원근/오류결론없음. 오크walk0/3y+1/+2행이동실험만·미적용. 대장원본경고6:0=death0좌·하단,원본부재손실px미상·후보경계접촉0으로원본경고취소안함.
- 4.7.2Xorg/Mesa실제12장: PRO-01도형마차2/CH1-01군집1/대장3패턴3/직업선택별2씩6. 강제해금/보스상태fixture이며자연진행/사람미술아님. 소스캡처/원문/workspace/.onboarding/P11-gui,검사run-p1g21kch.
- Windows기존preset의격리복제본에서4.7.2exe+pckbuildexit0,원본preset/main_scene불변. 검수전용user://namespace격리·실행cmd로기존3미션장면선택. Windows실행/물리GPU/사용자미술은미검증.
- 패키지pixel-forge/review/P11_review.zip: summary10줄·대표12장·판정overlay2장·lineup/측정/팔레트·exe/pck/실행2줄·해시. 이미지합계약3.5MiB<20MB. 원본17JSON·기본바인딩·기존후보·전투수치/히트박스/저장형식보존. 정식승격없음/새의존성0/이미지API0.

범위밖질문: art-source를원격보관할비공개저장소/기존저장소의비공개여부확인. 필요원본은최종보고요청줄1회로전달한다. 미술최종결론·잘림재요청판정은클로드가맡는다.
