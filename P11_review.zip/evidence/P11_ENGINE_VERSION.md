# P11 Godot 기준 고정

기준: **4.7.2.stable.official.ed1daf0bf**. 공식 linux x86_64와 export templates를 GitHub godotengine/godot 4.7.2-stable에서 받았으며 동일 릴리스 SHA512-SUMS.txt와 대조했다. 템플릿은 큰 파일 다운로드 시간제한 후 이어받아 검증 완료.

`GODOT_BIN=/workspace/tools/godot-4.7.2/Godot_v4.7.2-stable_linux.x86_64 python scripts/codex/dev_check.py --suite actor --suite p11 --suite mission --suite p11fx`

runner는 기대4.7.2와 다르면 경고하고 run/version.txt에 실제 버전을 보존한다. 4.6.3 결과는 참고다. 지시문 g2_timing은 기존 g2_render_contract의 시간/상태24건으로 대응한다.

|검사|4.6.3 기존 참고 passed/failed|4.7.2 P11 passed/failed|
|---|---:|---:|
|editor import|exit0|exit0|
|g1_manifest|11/0|11/0|
|g1_state|27/0|27/0|
|g1_actor_view|13/0|13/0|
|g2_render_contract(시간)|24/0|24/0|
|g2_presentation|26/0|26/0|
|demo_050_integration|52/0|52/0|
|P11 FX actual mapping|미구현|16/0|

Windows는 기존 Windows Desktop preset을 격리 프로젝트에서 사용하되 custom_template 경로를 검증된4.7.2 경로로 바꾸고 요청된 exe+pck를 위해 embed_pck=false로 출력한다. 검수 빌드의 user://는Seonggeom_P11_Review라는 별도경로로 격리하고 run_P11.cmd가 기존3미션장면을명시한다(기본main.tscn는그대로). 원본 preset/전투/저장형식/17JSON은 변경하지 않는다. 빌드는 검증하지만 Windows 실행/물리GPU/사용자미술 검증은 별도다.
