# P11 실제 공격 사양표

환산식: **radius_1x = reach × (2/3) ÷ 2 = reach/3**. com_001.gd world()·부채꼴 그리기와 Sprite2D 배율2 근거. combat_v04.strike_sector는 reach+enemy.radius로 대상 중심을 검사한다. 아래 호는 reach 기준이며 enemy.radius 확장은 별도다.

원본17JSON 수정 없음. pxl R=floor(reach/3)-2로 래스터/사전회전 여백을 두고 출력 QA에서 바깥호90~100%·각도±5°를 검사한다. 제시된 반지름은 전투 수치 변경이 아니다.

## 16_gameplay_v04.json families.*.levels[type=primary]

|family|level|reach|angle|waveRange|waveWidth|사용 여부|
|---|---:|---:|---:|---:|---:|---|
|C-B|1|110|100|360|42|현재 primary 계약·강화 후 다음 공격|
|C-B|2|110|140|360|42|현재 primary 계약·강화 후 다음 공격|
|C-B|3|110|140|360|42|현재 primary 계약·강화 후 다음 공격|
|C-B|4|110|140|360|42|현재 primary 계약·강화 후 다음 공격|
|C-B|5|140|140|360|42|현재 primary 계약·강화 후 다음 공격|
|G-B|1|130|140|380|80|현재 primary 계약·강화 후 다음 공격|
|G-B|2|130|180|380|110|현재 primary 계약·강화 후 다음 공격|
|G-B|3|130|180|380|110|현재 primary 계약·강화 후 다음 공격|
|G-B|4|130|180|380|110|현재 primary 계약·강화 후 다음 공격|
|G-B|5|130|180|380|110|현재 primary 계약·강화 후 다음 공격|
|S-B|1|110|100|440|38|현재 primary 계약·강화 후 다음 공격|
|S-B|2|110|100|440|38|현재 primary 계약·강화 후 다음 공격|
|S-B|3|110|100|440|38|현재 primary 계약·강화 후 다음 공격|
|S-B|4|110|100|440|55|현재 primary 계약·강화 후 다음 공격|
|S-B|5|110|100|520|55|현재 primary 계약·강화 후 다음 공격|
|R-B|1|120|110|400|55|현재 primary 계약·강화 후 다음 공격|
|R-B|2|120|110|400|55|현재 primary 계약·강화 후 다음 공격|
|R-B|3|120|110|400|55|현재 primary 계약·강화 후 다음 공격|
|R-B|4|120|110|400|55|현재 primary 계약·강화 후 다음 공격|
|R-B|5|120|110|400|55|현재 primary 계약·강화 후 다음 공격|

고유 검기 쌍: (110,100), (110,140), (120,110), (130,140), (130,180), (140,140)

## 04_skills.json angle 항목(옛 simulation 출처)

|JSON 경로|angle|현재 데모 사용 여부|
|---|---:|---|
|$.defaults.angle|0|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[0].spec.angle|90|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[0].spec.combo[2].angle|110|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[6].spec.angle|150|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[13].spec.angle|200|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[18].spec.angle|75|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[22].spec.angle|120|옛 simulation·현재 combat_v04 primary 표와 분리|
|$.skills[30].spec.angle|100|옛 simulation·현재 combat_v04 primary 표와 분리|

## Wave 비교(이번 연결 없음)

|waveRange|waveWidth|기존 fx_beam|일치 여부|
|---:|---:|---|---|
|360|42|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|380|80|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|380|110|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|400|55|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|440|38|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|440|55|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|
|520|55|native cell64×12→전투단위192×36, 첫 프레임 몸통60×8→180×24; 중앙앵커|불일치|

배율 환산은 셀 크기와 잉크 범위를 구분한다. 범위·폭·기점이 달라 wave를 fx_beam에 연결하지 않는다.

강화/유물 등 런타임 배율로 표 밖 reach/angle이 생기면 도형 fallback. 8방향 사전 생성은 그대로이며 실제 aim과 선택 행이5°를 초과하면 도형을 유지해 경계 오표시를 막는다.
