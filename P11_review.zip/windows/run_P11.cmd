@echo off
"%~dp0Seonggeom_P11.exe" res://demo/ch1_01/ch1_01.tscn -- --art-candidates
